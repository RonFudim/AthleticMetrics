class DatabaseError extends Error { }

module.exports = { DatabaseError };