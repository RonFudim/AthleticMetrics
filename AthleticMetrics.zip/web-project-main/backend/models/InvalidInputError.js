class InvalidInputError extends Error { }

module.exports = { InvalidInputError };