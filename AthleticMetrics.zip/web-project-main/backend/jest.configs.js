process.env = Object.assign(process.env, {
    CONSOLE_ONLY: "true",
    PINO_LOG_LEVEL: "error",
});